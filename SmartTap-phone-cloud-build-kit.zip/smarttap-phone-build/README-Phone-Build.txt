SMART TAP — BUILD APK USING ONLY YOUR PHONE

This project is built in GitHub Actions (cloud). You do not need a PC, but you need a GitHub account.

1. On your phone, open https://github.com/new and create a repository named SmartTapBuild. Public is easiest for this test project. Do not add a README or license during creation.
2. Open the new repository, tap Add file > Upload files, and upload SmartTapAndroid-source.zip from this package. Commit the upload.
3. Create the workflow file:
   - Tap Add file > Create new file.
   - In the filename box enter: .github/workflows/build-apk.yml
   - Open the build-apk.yml file from this package in a text editor, copy all its contents, and paste them into GitHub's editor.
   - Commit the new file.
4. Open the repository's Actions tab. If the workflow has not started, open “Build Smart Tap APK” and tap Run workflow.
5. Wait for the run to finish successfully. Open that run and find Artifacts. Download “SmartTap-debug-APK”.
6. Extract the downloaded artifact ZIP. It should contain app-debug.apk. Install that APK on your phone or transfer/download it into VSPhone.

IMPORTANT:
- This builds a DEBUG APK for testing; it is not a Play Store release.
- A successful build does not guarantee the automation works in VSPhone. Test carefully.
- The current prototype uses Android accessibility text matching. It does not yet include image/OCR recognition or a draggable floating auto-clicker.
- Do not put passwords, API keys, or private data in this repository.
